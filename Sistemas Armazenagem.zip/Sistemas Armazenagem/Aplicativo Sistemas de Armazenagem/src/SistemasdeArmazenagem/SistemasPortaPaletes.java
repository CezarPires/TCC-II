//** @author Cezar Andrade Pires
//** @data 03/11/2018

package SistemasdeArmazenagem;

import javax.swing.JOptionPane;

public class SistemasPortaPaletes extends javax.swing.JFrame {


    public SistemasPortaPaletes() {
        initComponents();
    
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        oPcaoSelecao = new javax.swing.JComboBox<>();
        jBescolheropcao = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jBsair = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Software de Engenharia para Cálculos de Sistemas de Armazenagem");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("SELECIONE A OPÇÃO DESEJADA");
        jLabel6.setToolTipText("Escolha o Sistema de Armazenagem");

        oPcaoSelecao.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        oPcaoSelecao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<Selecione uma opção>", "Ângulo Máximo Inclinação da Diagonal", "Características do aço", "Estados limites de serviço", "Imperfeições montantes não contraventados", "Largura do corredor ideal" }));

        jBescolheropcao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBescolheropcao.setText("CONFIRMAR SELEÇÃO");
        jBescolheropcao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBescolheropcaoActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 8)); // NOI18N
        jLabel3.setText("Cezar A. Pires .... V 1.00");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemasdeArmazenagem/PP01.jpg"))); // NOI18N
        jLabel1.setText("Imagem abertura PP01");

        jBsair.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBsair.setText("SAIR");
        jBsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBsairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(oPcaoSelecao, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBescolheropcao, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel3))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jBsair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(17, 17, 17)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oPcaoSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBescolheropcao)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jBsair)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
            
    private void jBescolheropcaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBescolheropcaoActionPerformed
        if (oPcaoSelecao.getSelectedItem().equals("<Selecione uma opção>")) {
            JOptionPane.showMessageDialog(null,"Esta não é uma seleção válida", null, WIDTH);
        }
        if (oPcaoSelecao.getSelectedItem().equals("Ângulo Máximo Inclinação da Diagonal")) {
                this.dispose();
                new AnguloMaximoInclinaçaoDiagonais().setVisible(true);
        }
        if (oPcaoSelecao.getSelectedItem().equals("Características do aço")) {
                this.dispose();
                new Característicasdoaço().setVisible(true);
        }
        if (oPcaoSelecao.getSelectedItem().equals("Estados limites de serviço")) {
                this.dispose();
                new EstadosLimitesdeServiço().setVisible(true);
        }
        if (oPcaoSelecao.getSelectedItem().equals("Imperfeições montantes não contraventados")) {
                this.dispose();
                new ImperfeiçõesMontantesNãoContraventados().setVisible(true);
        }
        if (oPcaoSelecao.getSelectedItem().equals("Largura do corredor ideal")) {
                this.dispose();
                new LarguraCorredor().setVisible(true);
        }
    }//GEN-LAST:event_jBescolheropcaoActionPerformed

    private void jBsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBsairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBsairActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new SistemasPortaPaletes().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBescolheropcao;
    private javax.swing.JButton jBsair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JComboBox<String> oPcaoSelecao;
    // End of variables declaration//GEN-END:variables
}
