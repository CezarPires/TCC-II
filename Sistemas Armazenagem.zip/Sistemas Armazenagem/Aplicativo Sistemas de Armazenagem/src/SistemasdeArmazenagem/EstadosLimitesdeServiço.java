package SistemasdeArmazenagem;

//** @author Cezar Andrade Pires
//** @data 03/11/2018

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import static java.awt.image.ImageObserver.WIDTH;
import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.io.IOException;

public class EstadosLimitesdeServiço extends javax.swing.JFrame {
    public EstadosLimitesdeServiço() {
        initComponents();
    }
    @SuppressWarnings ("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        resFlexaMaxLong = new javax.swing.JTextField();
        cLong = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jBcalcular = new javax.swing.JButton();
        jBsair = new javax.swing.JButton();
        jBimprimir = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        resTorcaoMaxLong = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        hEstrutura = new javax.swing.JTextField();
        resDeslTopoEstrutura = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jBlimpar = new javax.swing.JButton();
        jBvoltarmenu = new javax.swing.JButton();
        jLconclusão = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTAconclusao = new javax.swing.JTextArea();
        jLimagemapoio01 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 255));
        setLocation(new java.awt.Point(700, 150));
        setMinimumSize(null);
        setResizable(false);
        setSize(new java.awt.Dimension(960, 720));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("ESTADOS LIMITES DE SERVIÇO");
        jLabel1.setToolTipText("Escolha o Sistema de Armazenagem");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Software de Engenharia para Cálculos de Sistemas de Armazenagem");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("INFORME O COMPRIMENTO DA LONGARINA ................................");
        jLabel4.setToolTipText("O comprimento deverá ser em milímetros");

        resFlexaMaxLong.setEditable(false);
        resFlexaMaxLong.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        resFlexaMaxLong.setForeground(new java.awt.Color(0, 0, 255));

        cLong.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cLong.setToolTipText("Informe o comprimento em milímetros");
        cLong.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        cLong.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cLongKeyTyped(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("TORÇÃO MÁXIMA NA LONGARINA .........................................................");
        jLabel5.setToolTipText("");

        jBcalcular.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBcalcular.setText("CALCULAR");
        jBcalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBcalcularActionPerformed(evt);
            }
        });

        jBsair.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBsair.setText("SAIR");
        jBsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBsairActionPerformed(evt);
            }
        });

        jBimprimir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBimprimir.setText("IMPRIMIR");
        jBimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBimprimirActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("mm");
        jLabel7.setToolTipText("");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("FLECHA MÁXIMA NA LONGARINA ..........................................................");
        jLabel8.setToolTipText("");

        resTorcaoMaxLong.setEditable(false);
        resTorcaoMaxLong.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        resTorcaoMaxLong.setForeground(new java.awt.Color(0, 0, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("°  ");
        jLabel10.setToolTipText("");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel11.setText("DESLOCAMENTO NO TOPO DA ESTRUTURA SEM CARGA DE TRABALHO,");
        jLabel11.setToolTipText("");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel12.setText("COM AÇÕES  DEVIDAS ÀS IMPERFEIÇÕES OU DE CARGA VARIÁVEIS .....");
        jLabel12.setToolTipText("");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("INFORME A ALTURA TOTAL DA ESTRUTURA ................................");
        jLabel13.setToolTipText("A altura deverá ser em milímetros");

        hEstrutura.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        hEstrutura.setToolTipText("Informe a altura em milímetros");
        hEstrutura.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        hEstrutura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hEstruturaKeyTyped(evt);
            }
        });

        resDeslTopoEstrutura.setEditable(false);
        resDeslTopoEstrutura.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        resDeslTopoEstrutura.setForeground(new java.awt.Color(0, 0, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("mm");
        jLabel9.setToolTipText("");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("RESULTADOS");
        jLabel3.setToolTipText("Escolha o Sistema de Armazenagem");

        jBlimpar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBlimpar.setText("LIMPAR");
        jBlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBlimparActionPerformed(evt);
            }
        });

        jBvoltarmenu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBvoltarmenu.setText("VOLTAR AO MENU PRINCIPAL");
        jBvoltarmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBvoltarmenuActionPerformed(evt);
            }
        });

        jLconclusão.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLconclusão.setText("CONCLUSÃO");
        jLconclusão.setToolTipText("Escolha o Sistema de Armazenagem");

        jTAconclusao.setColumns(20);
        jTAconclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTAconclusao.setLineWrap(true);
        jTAconclusao.setRows(5);
        jTAconclusao.setToolTipText("");
        jTAconclusao.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTAconclusao);

        jLimagemapoio01.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemasdeArmazenagem/PP02.jpg"))); // NOI18N

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemasdeArmazenagem/PP04.jpg"))); // NOI18N
        jLabel6.setText("jLabel6");
        jLabel6.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cLong, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(hEstrutura, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(19, 19, 19))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(resTorcaoMaxLong, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(resFlexaMaxLong, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel7))
                                    .addComponent(jBlimpar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jBcalcular, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(resDeslTopoEstrutura, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel9))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(141, 141, 141)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(227, 227, 227)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(239, 239, 239)
                                .addComponent(jLconclusão))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addComponent(jLimagemapoio01))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jBvoltarmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jBimprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jBsair, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(jLabel2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cLong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(hEstrutura, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(13, 13, 13)
                .addComponent(jBcalcular)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBlimpar)
                .addGap(33, 33, 33)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(resFlexaMaxLong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(resTorcaoMaxLong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel12))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(resDeslTopoEstrutura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLimagemapoio01)
                .addGap(18, 18, 18)
                .addComponent(jLconclusão, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jBvoltarmenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBimprimir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBsair))
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel6))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
        Float comprimentolongarina, resultadoFlexa, torcaoMaxLong, alturaestrutura, resultadoDeslocamento;
        String comprimentoLong, alturaEstrut;
                    
    private void jBcalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBcalcularActionPerformed
        if (cLong.getText().equals("")) {
        JOptionPane.showMessageDialog(null,"Favor informar o comprimento da longarina", null, WIDTH);
        }
        if (hEstrutura.getText().equals("")) {
        JOptionPane.showMessageDialog(null,"Favor informar a altura da estrutura", null, WIDTH);
      }
        else {
               
        comprimentolongarina = Float.valueOf(cLong.getText());
        resultadoFlexa = comprimentolongarina / 200;
        resFlexaMaxLong.setText(String.valueOf(resultadoFlexa));
        
        torcaoMaxLong = comprimentolongarina - comprimentolongarina + 6;
        resTorcaoMaxLong.setText(String.valueOf(torcaoMaxLong));
        
        alturaestrutura = Float.valueOf(hEstrutura.getText());
        resultadoDeslocamento = alturaestrutura / 200;
        resDeslTopoEstrutura.setText(String.valueOf(resultadoDeslocamento));
        
        comprimentoLong = String.valueOf(cLong.getText());
        alturaEstrut = String.valueOf(hEstrutura.getText());
                
        jTAconclusao.setText(String.valueOf("CONCLUSÃO: " + " Com uma longarina de: " + (comprimentoLong) + " mm " + "e a estrutura com uma altura total de: " + (alturaEstrut) + " mm." + "  A flexa máxima da longarina é igual a: " + (resultadoFlexa) + " mm."   + "  A torção máxima na longarina é de: " + (torcaoMaxLong) + " °." + "  O deslocamento no topo da estrutura sem carga de trabalho com ações devidas as imperfeiçõs ou de carga variáveis é de: " + (resultadoDeslocamento) + " mm." ));
        
        }
    }//GEN-LAST:event_jBcalcularActionPerformed

    private void jBsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBsairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBsairActionPerformed

    private void jBimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBimprimirActionPerformed
    String resultadoFML, resultadoTML, resultadoDTE; 
    resultadoFML = String.valueOf(resFlexaMaxLong.getText());
    resultadoTML = String.valueOf(resTorcaoMaxLong.getText());
    resultadoDTE = String.valueOf(resDeslTopoEstrutura.getText());
    Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("C://temp//Estados limites servico.pdf"));
    document.open();
        boolean add;
        add = document.add(new Paragraph("Software de Engenharia para Cálculos de Sistemas de Armazenagem"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("Resultados: Estados limites de serviço"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("   FLECHA MÁXIMA NA LONGARINA :"+ "                 = " + resultadoFML + " mm"));
        add = document.add(new Paragraph("   TORÇÃO MÁXIMA NA LONGARINA :"+ "                 = " + resultadoTML + " °"));
        add = document.add(new Paragraph("   DESLOCAMENTO NO TOPO DA ESTRUTURA SEM CARGA DE TRABALHO, COM AÇÕES  DEVIDAS ÀS IMPERFEIÇÕES OU DE CARGA VARIÁVEIS : "+ "  = " + resultadoDTE + " mm"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("CONCLUSÃO: " + " Com uma longarina de: " + (comprimentoLong) + " mm " + "e a estrutura com uma altura total de: " + (alturaEstrut) + " mm." + "  A flexa máxima da longarina é igual a: " + (resultadoFlexa) + " mm."   + "  A torção máxima na longarina é de: " + (torcaoMaxLong) + " °." + "  O deslocamento no topo da estrutura sem carga de trabalho com ações devidas as imperfeiçõs ou de carga variáveis é de: " + (resultadoDeslocamento) + " mm." ));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));
            
        JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Estados limites servico)", null, WIDTH);
    }
    catch(DocumentException | IOException de)
    { System.err.println(de.getMessage());
    }
    document.close(); 
    }//GEN-LAST:event_jBimprimirActionPerformed

    private void jBlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBlimparActionPerformed
        cLong.setText("");
        hEstrutura.setText("");
        resFlexaMaxLong.setText("");
        resTorcaoMaxLong.setText("");
        resDeslTopoEstrutura.setText("");
        jTAconclusao.setText("");
    }//GEN-LAST:event_jBlimparActionPerformed

    private void jBvoltarmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBvoltarmenuActionPerformed
        this.dispose();
        new SistemasPortaPaletes().setVisible(true);
    }//GEN-LAST:event_jBvoltarmenuActionPerformed

    private void cLongKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cLongKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_cLongKeyTyped

    private void hEstruturaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hEstruturaKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_hEstruturaKeyTyped

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new EstadosLimitesdeServiço().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cLong;
    private javax.swing.JTextField hEstrutura;
    private javax.swing.JButton jBcalcular;
    private javax.swing.JButton jBimprimir;
    private javax.swing.JButton jBlimpar;
    private javax.swing.JButton jBsair;
    private javax.swing.JButton jBvoltarmenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLconclusão;
    private javax.swing.JLabel jLimagemapoio01;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTAconclusao;
    private javax.swing.JTextField resDeslTopoEstrutura;
    private javax.swing.JTextField resFlexaMaxLong;
    private javax.swing.JTextField resTorcaoMaxLong;
    // End of variables declaration//GEN-END:variables


}