package SistemasdeArmazenagem;
//** @author Cezar Andrade Pires
//** @data 03/11/2018

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import static java.lang.Math.atan;
import javax.swing.JOptionPane;


public class AnguloMaximoInclinaçaoDiagonais extends javax.swing.JFrame {

    
    public AnguloMaximoInclinaçaoDiagonais() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLanguloMdiagonal = new javax.swing.JLabel();
        jLprofundidadeMontante = new javax.swing.JLabel();
        profMontante = new javax.swing.JTextField();
        jLdistanciaEtravessas = new javax.swing.JLabel();
        distEtravessas = new javax.swing.JTextField();
        jBcalcular = new javax.swing.JButton();
        jBlimpar = new javax.swing.JButton();
        resAmInclinDiagText = new javax.swing.JLabel();
        resAngDiag = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jBvoltarmenu = new javax.swing.JButton();
        jBimprimir = new javax.swing.JButton();
        jBsair = new javax.swing.JButton();
        jLconclusao = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        mensagemConclusao = new javax.swing.JTextArea();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Software de Engenharia para Cálculos de Sistemas de Armazenagem");

        jLanguloMdiagonal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLanguloMdiagonal.setText("ÂNGULO MÁXIMO DA INCLINAÇÃO DA DIAGONAL");
        jLanguloMdiagonal.setToolTipText("Escolha o Sistema de Armazenagem");

        jLprofundidadeMontante.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLprofundidadeMontante.setText("INFORME A PROFUNDIDADE DO MONTANTE ...................................");
        jLprofundidadeMontante.setToolTipText("A profudidade do montante deverá ser em milímetros.");

        profMontante.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        profMontante.setToolTipText("Informe a profundidade em milímetros");
        profMontante.setAutoscrolls(false);
        profMontante.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        profMontante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                profMontanteKeyTyped(evt);
            }
        });

        jLdistanciaEtravessas.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLdistanciaEtravessas.setText("INFORME A DISTÂNCIA ENTRE AS TRAVESSAS ..............................");
        jLdistanciaEtravessas.setToolTipText("A distância entre travessas deverá ser em milímetros.");

        distEtravessas.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        distEtravessas.setToolTipText("Informe a distância em milímetros");
        distEtravessas.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        distEtravessas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                distEtravessasKeyTyped(evt);
            }
        });

        jBcalcular.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBcalcular.setText("CALCULAR");
        jBcalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBcalcularActionPerformed(evt);
            }
        });

        jBlimpar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBlimpar.setText("LIMPAR");
        jBlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBlimparActionPerformed(evt);
            }
        });

        resAmInclinDiagText.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        resAmInclinDiagText.setText("O ÂNGULO DA DIAGONAL É IGUAL A:  .....................");
        resAmInclinDiagText.setToolTipText("");

        resAngDiag.setEditable(false);
        resAngDiag.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        resAngDiag.setForeground(new java.awt.Color(0, 0, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("°  ");
        jLabel10.setToolTipText("");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("RESULTADO");
        jLabel3.setToolTipText("Escolha o Sistema de Armazenagem");

        jBvoltarmenu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBvoltarmenu.setText("VOLTAR AO MENU PRINCIPAL");
        jBvoltarmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBvoltarmenuActionPerformed(evt);
            }
        });

        jBimprimir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBimprimir.setText("IMPRIMIR");
        jBimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBimprimirActionPerformed(evt);
            }
        });

        jBsair.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBsair.setText("SAIR");
        jBsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBsairActionPerformed(evt);
            }
        });

        jLconclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLconclusao.setText("CONCLUSÃO");
        jLconclusao.setToolTipText("");

        mensagemConclusao.setColumns(20);
        mensagemConclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mensagemConclusao.setLineWrap(true);
        mensagemConclusao.setRows(5);
        mensagemConclusao.setToolTipText("");
        mensagemConclusao.setWrapStyleWord(true);
        jScrollPane1.setViewportView(mensagemConclusao);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jBimprimir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBsair, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBvoltarmenu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 11, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLanguloMdiagonal, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLprofundidadeMontante)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(profMontante, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLdistanciaEtravessas)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(distEtravessas, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jBcalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jBlimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(227, 227, 227)
                        .addComponent(jLconclusao))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(resAmInclinDiagText)
                                .addGap(18, 18, 18)
                                .addComponent(resAngDiag, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel10))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(216, 216, 216)
                                .addComponent(jLabel3)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLanguloMdiagonal)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLprofundidadeMontante)
                    .addComponent(profMontante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLdistanciaEtravessas)
                    .addComponent(distEtravessas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jBcalcular)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBlimpar)
                .addGap(29, 29, 29)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resAmInclinDiagText, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(resAngDiag, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(jLconclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addComponent(jBvoltarmenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBimprimir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBsair))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    Float profundMontante, distanciaEtravessas, angulodiag, angulotang;
    Double  resultadoangulodiag;
    private void jBcalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBcalcularActionPerformed

        if (profMontante.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a profundidade do montante", null, WIDTH);
        }
        if (distEtravessas.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a distância entre travessas", null, WIDTH);
        }
        
        else {

            profundMontante = Float.valueOf(profMontante.getText());
            distanciaEtravessas = Float.valueOf(distEtravessas.getText());
            angulodiag = distanciaEtravessas / profundMontante;
            double pi = 3.14;
            float angulo = 180;
            float angulopi;
            angulopi = (float) ((float) angulo / pi);
            double arcotan;
            arcotan = atan(angulodiag);
            resultadoangulodiag = arcotan * angulopi;
            resAngDiag.setText(String.valueOf(resultadoangulodiag));
            
            if (resultadoangulodiag >= 25 && resultadoangulodiag <= 65) {
            mensagemConclusao.setText(String.valueOf("CONCLUSÃO: " + " Com um montante de " + (profundMontante) + " mm " + "de profundidade e com as travessas a uma distância de " + (distanciaEtravessas) + " mm," + "  o ângulo de inclinação das diagonais é igual a " + (resultadoangulodiag) + " ° e está dentro da faixa aceitável."));
            }
            if (resultadoangulodiag < 25) {
            mensagemConclusao.setText(String.valueOf("CONCLUSÃO: " + " Com um montante de " + (profundMontante) + " mm " + "de profundidade e com as travessas a uma distância de " + (distanciaEtravessas) + " mm," + "  o ângulo de inclinação das diagonais é igual a " + (resultadoangulodiag) + " ° e está abaixo da faixa aceitável."));
            }
            if (resultadoangulodiag > 65) {
            mensagemConclusao.setText(String.valueOf("CONCLUSÃO: " + " Com um montante de " + (profundMontante) + " mm " + "de profundidade e com as travessas a uma distância de " + (distanciaEtravessas) + " mm," + "  o ângulo de inclinação das diagonais é igual a " + (resultadoangulodiag) + " ° e está acima da faixa aceitável."));
            }
        }
    }//GEN-LAST:event_jBcalcularActionPerformed

    private void jBlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBlimparActionPerformed
        profMontante.setText("");
        distEtravessas.setText("");
        resAngDiag.setText("");
        mensagemConclusao.setText("");
    }//GEN-LAST:event_jBlimparActionPerformed

    private void jBvoltarmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBvoltarmenuActionPerformed
        this.dispose();
        new SistemasPortaPaletes().setVisible(true);
    }//GEN-LAST:event_jBvoltarmenuActionPerformed

    private void jBimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBimprimirActionPerformed
        String profMontPDF, distTravPDF;
        profMontPDF = String.valueOf(profMontante.getText());
        distTravPDF = String.valueOf(distEtravessas.getText());
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("C://temp//Angulo Maximo Inclinacao Diagonal.pdf"));
            document.open();
            boolean add;
            add = document.add(new Paragraph("Software de Engenharia para Cálculos de Sistemas de Armazenagem"));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("Resultados: Ângulo Máximo da Inclinação das Diagonais"));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("   Profundidade do montante = " + (profMontPDF) + " mm "));
            add = document.add(new Paragraph("   Distância entre travessas = " + (distTravPDF) + " mm "));
            
            if (resultadoangulodiag >= 25 && resultadoangulodiag <= 65) {
            add = document.add(new Paragraph( "Conclusão:  Com um montante de " + (profMontPDF) + " mm de profundidade e com as travessas a uma distância de " + (distTravPDF) + " mm," + "  o ângulo de inclinação das diagonais é igual a " + (resultadoangulodiag) + " ° e está dentro da faixa aceitável."));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));
            JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Angulo Maximo Inclinacao Diagonal)", null, WIDTH);
            }
            if (resultadoangulodiag < 25) {
            add = document.add(new Paragraph( "Conclusão:  Com um montante de " + (profMontPDF) + " mm de profundidade e com as travessas a uma distância de " + (distTravPDF) + " mm," + "  o ângulo de inclinação das diagonais é igual a " + (resultadoangulodiag) + " ° e está abaixo da faixa aceitável."));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));
            JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Angulo Maximo Inclinacao Diagonal)", null, WIDTH);
            }
            if (resultadoangulodiag > 65) {
            add = document.add(new Paragraph( "Conclusão:  Com um montante de " + (profMontPDF) + " mm de profundidade e com as travessas a uma distância de " + (distTravPDF) + " mm," + "  o ângulo de inclinação das diagonais é igual a " + (resultadoangulodiag) + " ° e está acima da faixa aceitável."));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));
            JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Angulo Maximo Inclinacao Diagonal)", null, WIDTH);
            }
        }
        catch(DocumentException | IOException de)
        { System.err.println(de.getMessage());
        }
        document.close();
    }//GEN-LAST:event_jBimprimirActionPerformed

    private void jBsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBsairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBsairActionPerformed

    private void profMontanteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_profMontanteKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_profMontanteKeyTyped

    private void distEtravessasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_distEtravessasKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_distEtravessasKeyTyped

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> {
            new AnguloMaximoInclinaçaoDiagonais().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField distEtravessas;
    private javax.swing.JButton jBcalcular;
    private javax.swing.JButton jBimprimir;
    private javax.swing.JButton jBlimpar;
    private javax.swing.JButton jBsair;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jBvoltarmenu;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLanguloMdiagonal;
    private javax.swing.JLabel jLconclusao;
    private javax.swing.JLabel jLdistanciaEtravessas;
    private javax.swing.JLabel jLprofundidadeMontante;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea mensagemConclusao;
    private javax.swing.JTextField profMontante;
    private javax.swing.JLabel resAmInclinDiagText;
    private javax.swing.JTextField resAngDiag;
    // End of variables declaration//GEN-END:variables
}