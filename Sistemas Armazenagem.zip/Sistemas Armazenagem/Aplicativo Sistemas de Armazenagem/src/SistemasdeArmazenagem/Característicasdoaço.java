package SistemasdeArmazenagem;

 //** @author Cezar Andrade Pires
//** @data 03/11/2018

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JOptionPane;


public class Característicasdoaço extends javax.swing.JFrame {
    
    public Característicasdoaço() {
        initComponents();
    }
    String  massaEspecifica, moduloElasticidade, coeficientePoisson, moduloTelasticidade, coeficienteDilatacao;
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jBvoltarmenu = new javax.swing.JButton();
        jBsair = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        mEspecifica = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        mElasticidade = new javax.swing.JTextField();
        cPoisson = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        mTElasticidade = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cDilatacao = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jBimprimir = new javax.swing.JButton();
        jLimagemaço = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(0, 204, 255));
        setLocation(new java.awt.Point(700, 150));
        setMinimumSize(new java.awt.Dimension(540, 540));
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Software de Engenharia para Cálculos de Sistemas de Armazenagem");

        jBvoltarmenu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBvoltarmenu.setText("VOLTAR AO MENU PRINCIPAL");
        jBvoltarmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBvoltarmenuActionPerformed(evt);
            }
        });

        jBsair.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBsair.setText("SAIR");
        jBsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBsairActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("CARACTERÍSTICAS DO AÇO");
        jLabel1.setToolTipText("Escolha o Sistema de Armazenagem");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("MASSA ESPECÍFICA (p) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ");
        jLabel4.setToolTipText("Escolha o Sistema de Armazenagem");

        mEspecifica.setEditable(false);
        mEspecifica.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mEspecifica.setText("7850 Kg/m³");
        mEspecifica.setToolTipText("");
        mEspecifica.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("MÓDULO DE ELASTICIDADE (E) . . . . . . . . . . . . . . . . . . . . . . . . . . . . .");
        jLabel5.setToolTipText("Escolha o Sistema de Armazenagem");

        mElasticidade.setEditable(false);
        mElasticidade.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mElasticidade.setText("250000 MPa");
        mElasticidade.setToolTipText("");
        mElasticidade.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        cPoisson.setEditable(false);
        cPoisson.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cPoisson.setText("0,3");
        cPoisson.setToolTipText("");
        cPoisson.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("COEFICIENTE DE POISSON NO REGIME ELÁSTICO (v) . . . . . . . . . . . . . ");
        jLabel6.setToolTipText("Escolha o Sistema de Armazenagem");

        mTElasticidade.setEditable(false);
        mTElasticidade.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mTElasticidade.setText("78850 MPa");
        mTElasticidade.setToolTipText("");
        mTElasticidade.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("MÓDULOS TRANSVERSAL DE ELASTICIDADE (G) . . . . . . . . . . . . . . . . ");
        jLabel7.setToolTipText("Escolha o Sistema de Armazenagem");

        cDilatacao.setEditable(false);
        cDilatacao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cDilatacao.setText("12x10-⁶ / °C");
        cDilatacao.setToolTipText("");
        cDilatacao.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        cDilatacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cDilatacaoActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("COEFICIENTE DE DILATAÇÃO TÉRMICA (α) . . . . . . . . . . . . . . . . . . . . ");
        jLabel8.setToolTipText("Escolha o Sistema de Armazenagem");

        jBimprimir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBimprimir.setText("IMPRIMIR");
        jBimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBimprimirActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemasdeArmazenagem/BB01.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel4))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(cDilatacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 7, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(mEspecifica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jBsair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jBimprimir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cPoisson, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(mTElasticidade, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(mElasticidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jBvoltarmenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(jLimagemaço)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel2)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mEspecifica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mElasticidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cPoisson, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mTElasticidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cDilatacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLimagemaço, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel3)))
                .addGap(18, 18, 18)
                .addComponent(jBvoltarmenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBimprimir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBsair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jBvoltarmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBvoltarmenuActionPerformed
        this.dispose();
        new SistemasPortaPaletes().setVisible(true);
    }//GEN-LAST:event_jBvoltarmenuActionPerformed

    private void jBsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBsairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBsairActionPerformed

    private void cDilatacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cDilatacaoActionPerformed
        
    }//GEN-LAST:event_cDilatacaoActionPerformed

    private void jBimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBimprimirActionPerformed
    massaEspecifica = String.valueOf(mEspecifica.getText());
    moduloElasticidade = String.valueOf(mElasticidade.getText());
    coeficientePoisson = String.valueOf(cPoisson.getText());
    moduloTelasticidade = String.valueOf(mTElasticidade.getText());
    coeficienteDilatacao = String.valueOf(cDilatacao.getText());
        Document document = new Document();
    try {
        PdfWriter.getInstance(document, new FileOutputStream("C://temp//Características do aço.pdf"));
    document.open();
        boolean add;
        add = document.add(new Paragraph("Software de Engenharia para Cálculos de Sistemas de Armazenagem"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("Resultados: Características do Aço"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("   MASSA ESPECÍFICA (p) :"+ "                           = " + massaEspecifica));
        add = document.add(new Paragraph("   MÓDULO DE ELASTICIDADE (E) :"+ "                     = " + moduloElasticidade));
        add = document.add(new Paragraph("   COEFICIENTE DE POISSON NO REGIME ELÁSTICO (v): "+ "  = " + coeficientePoisson));
        add = document.add(new Paragraph("   MÓDULOS TRANSVERSAL DE ELASTICIDADE (G): "+ "        = " + moduloTelasticidade));
        add = document.add(new Paragraph("   COEFICIENTE DE DILATAÇÃO TÉRMICA (α): "+ "           = " + coeficienteDilatacao));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));
            
        JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Características do aço)", null, WIDTH);
    }
    catch(DocumentException | IOException de)
    { System.err.println(de.getMessage());
    }
    document.close(); 
    }//GEN-LAST:event_jBimprimirActionPerformed

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> {
            new Característicasdoaço().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cDilatacao;
    private javax.swing.JTextField cPoisson;
    private javax.swing.JButton jBimprimir;
    private javax.swing.JButton jBsair;
    private javax.swing.JButton jBvoltarmenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLimagemaço;
    private javax.swing.JTextField mElasticidade;
    private javax.swing.JTextField mEspecifica;
    private javax.swing.JTextField mTElasticidade;
    // End of variables declaration//GEN-END:variables
}
