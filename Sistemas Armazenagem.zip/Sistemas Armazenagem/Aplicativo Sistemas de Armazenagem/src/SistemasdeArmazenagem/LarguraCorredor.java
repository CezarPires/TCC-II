package SistemasdeArmazenagem;

 //** @author Cezar Andrade Pires
//** @data 03/11/2018

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JOptionPane;


public class LarguraCorredor extends javax.swing.JFrame {


    public LarguraCorredor() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLcorredorOperacional = new javax.swing.JLabel();
        lCorOper = new javax.swing.JTextField();
        jBalancoPalete = new javax.swing.JLabel();
        bLanPalete = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jBvoltarmenu = new javax.swing.JButton();
        jBimprimir = new javax.swing.JButton();
        jBsair = new javax.swing.JButton();
        eMaxGarfoEmp = new javax.swing.JTextField();
        jElevaMaxGarfEmp = new javax.swing.JLabel();
        jAltMaxTorreEmpRecuada = new javax.swing.JLabel();
        aMaxTorreEmpRec = new javax.swing.JTextField();
        jLcorredorIdeal = new javax.swing.JLabel();
        rescorredoideal = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jBcalcular = new javax.swing.JButton();
        jBlimpar = new javax.swing.JButton();
        jLalturamaxultlong = new javax.swing.JLabel();
        resaatddealultlong = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLalturamaxtorrerecu = new javax.swing.JLabel();
        resaatddealtunel = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLconclusao = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        mensagemConclusao = new javax.swing.JTextArea();
        jLimagemapoio = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Software de Engenharia para Cálculos de Sistemas de Armazenagem");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("LARGURA DO CORREDOR IDEAL");
        jLabel1.setToolTipText("Escolha o Sistema de Armazenagem");

        jLcorredorOperacional.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLcorredorOperacional.setText("INFORME A LARGURA DO CORREDOR OPERACIONAL ....................");
        jLcorredorOperacional.setToolTipText("O comprimento deverá ser em milímetros e é definido pelo tipo de equipamento de movimentação (consultar catálogo do equipamento)");

        lCorOper.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lCorOper.setToolTipText("Informe o comprimento em milímetros");
        lCorOper.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        lCorOper.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                lCorOperKeyTyped(evt);
            }
        });

        jBalancoPalete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBalancoPalete.setText("INFORME A MEDIDA DO BALANÇO DO PALETE ..............................");
        jBalancoPalete.setToolTipText("O balanço do palete deverá ser em milímetros. O balanço é a medida que o palete fica para fora da estrutura.");

        bLanPalete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        bLanPalete.setToolTipText("Informe o comprimento em milímetros");
        bLanPalete.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        bLanPalete.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bLanPaleteKeyTyped(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("RESULTADOS");
        jLabel3.setToolTipText("Escolha o Sistema de Armazenagem");

        jBvoltarmenu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBvoltarmenu.setText("VOLTAR AO MENU PRINCIPAL");
        jBvoltarmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBvoltarmenuActionPerformed(evt);
            }
        });

        jBimprimir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBimprimir.setText("IMPRIMIR");
        jBimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBimprimirActionPerformed(evt);
            }
        });

        jBsair.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBsair.setText("SAIR");
        jBsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBsairActionPerformed(evt);
            }
        });

        eMaxGarfoEmp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        eMaxGarfoEmp.setToolTipText("Informe o comprimento em milímetros");
        eMaxGarfoEmp.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        eMaxGarfoEmp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                eMaxGarfoEmpKeyTyped(evt);
            }
        });

        jElevaMaxGarfEmp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jElevaMaxGarfEmp.setText("INFORME MEDIDA ELEVAÇÃO MÁXIMA GARFO EMPILHADEIRA .....");
        jElevaMaxGarfEmp.setToolTipText("A elevação máxima do garfo deverá ser em milímetros. Esta elevação é encontrada no catálogo do equipamento");

        jAltMaxTorreEmpRecuada.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jAltMaxTorreEmpRecuada.setText("INFORME ALTURA MÁXIMA TORRE RECUADA EMPILHADEIRA ......");
        jAltMaxTorreEmpRecuada.setToolTipText("A elevação máxima do garfo deverá ser em milímetros. Esta elevação é encontrada no catálogo do equipamento");

        aMaxTorreEmpRec.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        aMaxTorreEmpRec.setToolTipText("Informe o comprimento em milímetros");
        aMaxTorreEmpRec.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        aMaxTorreEmpRec.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                aMaxTorreEmpRecKeyTyped(evt);
            }
        });

        jLcorredorIdeal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLcorredorIdeal.setText("O CORREDOR IDEAL DEVERÁ TER NO MÍNIMO .......................................");
        jLcorredorIdeal.setToolTipText("");

        rescorredoideal.setEditable(false);
        rescorredoideal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rescorredoideal.setForeground(new java.awt.Color(0, 0, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("mm");
        jLabel7.setToolTipText("");

        jBcalcular.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBcalcular.setText("CALCULAR");
        jBcalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBcalcularActionPerformed(evt);
            }
        });

        jBlimpar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBlimpar.setText("LIMPAR");
        jBlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBlimparActionPerformed(evt);
            }
        });

        jLalturamaxultlong.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLalturamaxultlong.setText("A ALTURA MÁXIMA IDEAL DA ÚLTIMA LONGARINA DEVERÁ SER ..........");
        jLalturamaxultlong.setToolTipText("");

        resaatddealultlong.setEditable(false);
        resaatddealultlong.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        resaatddealultlong.setForeground(new java.awt.Color(0, 0, 255));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("mm");
        jLabel8.setToolTipText("");

        jLalturamaxtorrerecu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLalturamaxtorrerecu.setText("A ALTURA MÍNIMA IDEAL DO TÚNEL DEVERÁ SER .................................");
        jLalturamaxtorrerecu.setToolTipText("");

        resaatddealtunel.setEditable(false);
        resaatddealtunel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        resaatddealtunel.setForeground(new java.awt.Color(0, 0, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("mm");
        jLabel9.setToolTipText("");

        jLconclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLconclusao.setText("CONCLUSÃO");
        jLconclusao.setToolTipText("");

        mensagemConclusao.setColumns(20);
        mensagemConclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mensagemConclusao.setLineWrap(true);
        mensagemConclusao.setRows(5);
        mensagemConclusao.setToolTipText("");
        mensagemConclusao.setWrapStyleWord(true);
        jScrollPane1.setViewportView(mensagemConclusao);

        jLimagemapoio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PP06.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 10, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(158, 158, 158)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLcorredorOperacional)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lCorOper, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jBlimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLcorredorIdeal)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(145, 145, 145)))
                            .addComponent(rescorredoideal, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(1, 1, 1)
                            .addComponent(jLabel7))
                        .addComponent(jBcalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLalturamaxultlong)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(resaatddealultlong, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel8))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLalturamaxtorrerecu)
                                .addGap(10, 10, 10)
                                .addComponent(resaatddealtunel, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jElevaMaxGarfEmp)
                                .addComponent(jAltMaxTorreEmpRecuada)
                                .addComponent(jBalancoPalete))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(bLanPalete)
                                .addComponent(aMaxTorreEmpRec, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(eMaxGarfoEmp, javax.swing.GroupLayout.Alignment.LEADING))
                            .addGap(20, 20, 20)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jBimprimir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBsair, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBvoltarmenu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addComponent(jLconclusao)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLimagemapoio)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLcorredorOperacional)
                    .addComponent(lCorOper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBalancoPalete)
                    .addComponent(bLanPalete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jElevaMaxGarfEmp)
                    .addComponent(eMaxGarfoEmp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAltMaxTorreEmpRecuada)
                    .addComponent(aMaxTorreEmpRec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jBcalcular)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBlimpar)
                .addGap(26, 26, 26)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rescorredoideal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLcorredorIdeal))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(resaatddealultlong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLalturamaxultlong))
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resaatddealtunel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLalturamaxtorrerecu))
                .addGap(61, 61, 61)
                .addComponent(jLconclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBvoltarmenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBimprimir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBsair))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLimagemapoio))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    Float corredorideal, balancopalete, resultadocorredorideal, alturaideallong,resultaltidealultlong, altidultlong, alturaidealtunel, autidealtunel;
    Integer auxMult2, auxiSub200, auxiAd200;
    
    
    private void jBvoltarmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBvoltarmenuActionPerformed
        this.dispose();
        new SistemasPortaPaletes().setVisible(true);
    }//GEN-LAST:event_jBvoltarmenuActionPerformed

    private void jBimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBimprimirActionPerformed
      String rescorredoidealPDF, resaatddealultlongPDF, resaatddealtunelPDF;
      rescorredoidealPDF = String.valueOf(rescorredoideal.getText());
      resaatddealultlongPDF = String.valueOf(resaatddealultlong.getText());
      resaatddealtunelPDF = String.valueOf(resaatddealtunel.getText());
      resaatddealultlongPDF = String.valueOf(resaatddealultlong.getText());
              
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("C://temp//Largura Corredor Ideal.pdf"));
            document.open();
            boolean add;
            add = document.add(new Paragraph("Software de Engenharia para Cálculos de Sistemas de Armazenagem"));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("Resultados: Largura corredor ideal"));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("   O CORREDOR IDEAL DEVERÁ TER NO MÍNIMO: " + (rescorredoidealPDF) + " mm."));
            add = document.add(new Paragraph("   A ALTURA IDEAL DA ÚLTIMA LONGARINA DEVERÁ SER DE :" + (resaatddealultlongPDF) + " mm."));
            add = document.add(new Paragraph("   A ALTURA MÍNIMA IDEAL DO TÚNEL DEVERÁ SER DE: " + (resaatddealtunelPDF) + " mm"));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("CONCLUSÃO: " + " Com um corredor operacional de " + (corredorideal) + " mm " + "e o balanço do pallet igual a " + (balancopalete) + " mm," + " o corredor ideal deverá ser de " + (resultadocorredorideal) + " mm." + " E com a elevação máxima do garfo da empilhadeira de "+ (alturaideallong) + " mm" + " a altura da última longarina deverá ser de " + (resaatddealultlongPDF)+ " mm." + " E com a altura máxima da torre recuada de " + (alturaidealtunel) + ", o túnel deverá ter no mínimo " + (resaatddealtunelPDF) + " mm."));
            add = document.add(new Paragraph(" "));
            add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));

            JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Largura Corredor Ideal)", null, WIDTH);
        }
        catch(DocumentException | IOException de)
        { System.err.println(de.getMessage());
        }
        document.close();
    }//GEN-LAST:event_jBimprimirActionPerformed

    private void jBsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBsairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBsairActionPerformed

    private void jBcalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBcalcularActionPerformed
        
        if (lCorOper.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a largura do corredor operacional", null, WIDTH);
        }
        if (bLanPalete.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a medida do balanço do pallet", null, WIDTH);
        }
        if (eMaxGarfoEmp.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a medida da elevação máxima do garfo da empilhadeira", null, WIDTH);
        }
        if (aMaxTorreEmpRec.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a altura máxima da torre recuada da empilhadeira", null, WIDTH);
        }
            else {
                        
            corredorideal = Float.valueOf(lCorOper.getText());
            balancopalete = Float.valueOf(bLanPalete.getText());
            auxMult2 = 2;
            float auxiliarMultiplicar;
            auxiliarMultiplicar = auxMult2 * balancopalete;
            resultadocorredorideal = corredorideal + auxiliarMultiplicar;
            rescorredoideal.setText(String.valueOf(resultadocorredorideal));
            
            alturaideallong = Float.valueOf(eMaxGarfoEmp.getText());
            auxiSub200 = 200;
            float auxiliarSub;
            auxiliarSub = auxiSub200;
            altidultlong = alturaideallong - auxiliarSub;
            resaatddealultlong.setText(String.valueOf(altidultlong));
                    
            alturaidealtunel = Float.valueOf(aMaxTorreEmpRec.getText());
            auxiAd200 = 200;
            float auxiliarAdi;
            auxiliarAdi = auxiAd200;
            autidealtunel = alturaidealtunel + auxiliarAdi;
            resaatddealtunel.setText(String.valueOf(autidealtunel));
            
            mensagemConclusao.setText(String.valueOf("CONCLUSÃO: " + " Com um corredor operacional de " + (corredorideal) + " mm " + "e o balanço do pallet igual a " + (balancopalete) + " mm," + "  o corredor ideal deverá ser de " + (resultadocorredorideal) + " mm. " + "E com a elevação máxima do garfo da empilhadeira de "+ (alturaideallong) + " mm" + " a altura da última longarina deverá ser de " + (altidultlong)+ " mm. " + "E com a altura máxima da torre recuada de " + (alturaidealtunel) + " mm, o túnel deverá ter no mínimo " + (autidealtunel) + " mm."));

        }
    }//GEN-LAST:event_jBcalcularActionPerformed

    private void jBlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBlimparActionPerformed
        lCorOper.setText("");
        bLanPalete.setText("");
        eMaxGarfoEmp.setText("");
        aMaxTorreEmpRec.setText("");
        rescorredoideal.setText("");
        resaatddealultlong.setText("");
        resaatddealtunel.setText("");
        
    }//GEN-LAST:event_jBlimparActionPerformed

    private void lCorOperKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lCorOperKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_lCorOperKeyTyped

    private void bLanPaleteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bLanPaleteKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_bLanPaleteKeyTyped

    private void eMaxGarfoEmpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eMaxGarfoEmpKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_eMaxGarfoEmpKeyTyped

    private void aMaxTorreEmpRecKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aMaxTorreEmpRecKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_aMaxTorreEmpRecKeyTyped

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new LarguraCorredor().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aMaxTorreEmpRec;
    private javax.swing.JTextField bLanPalete;
    private javax.swing.JTextField eMaxGarfoEmp;
    private javax.swing.JLabel jAltMaxTorreEmpRecuada;
    private javax.swing.JLabel jBalancoPalete;
    private javax.swing.JButton jBcalcular;
    private javax.swing.JButton jBimprimir;
    private javax.swing.JButton jBlimpar;
    private javax.swing.JButton jBsair;
    private javax.swing.JButton jBvoltarmenu;
    private javax.swing.JLabel jElevaMaxGarfEmp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLalturamaxtorrerecu;
    private javax.swing.JLabel jLalturamaxultlong;
    private javax.swing.JLabel jLconclusao;
    private javax.swing.JLabel jLcorredorIdeal;
    private javax.swing.JLabel jLcorredorOperacional;
    private javax.swing.JLabel jLimagemapoio;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lCorOper;
    private javax.swing.JTextArea mensagemConclusao;
    private javax.swing.JTextField resaatddealtunel;
    private javax.swing.JTextField resaatddealultlong;
    private javax.swing.JTextField rescorredoideal;
    // End of variables declaration//GEN-END:variables
}
