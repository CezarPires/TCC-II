package SistemasdeArmazenagem;

//** @author Cezar Andrade Pires
//** @data 03/11/2018

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JOptionPane;

public class ImperfeiçõesMontantesNãoContraventados extends javax.swing.JFrame {

    public ImperfeiçõesMontantesNãoContraventados() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        respostaResultado2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLresultado = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        nMontantesConjunto = new javax.swing.JTextField();
        hEstrutura = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        qParesLongarinas = new javax.swing.JTextField();
        dVerticalForaPrumo = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jBcalcular = new javax.swing.JButton();
        jBlimpar = new javax.swing.JButton();
        respostaResultado = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jBimprimir = new javax.swing.JButton();
        jBsair = new javax.swing.JButton();
        mensagemConclusao = new javax.swing.JTextField();
        jBvoltarmenu1 = new javax.swing.JButton();
        jLconclusao = new javax.swing.JLabel();
        jPanelImagemApoio = new javax.swing.JPanel();
        jLimagemapoio = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jRadioButton1.setText("jRadioButton1");

        respostaResultado2.setEditable(false);
        respostaResultado2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        respostaResultado2.setToolTipText("Informe a distância entre a vertical e posição fora de prumo");
        respostaResultado2.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(700, 150));
        setMinimumSize(new java.awt.Dimension(540, 540));
        setResizable(false);
        setSize(new java.awt.Dimension(540, 540));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Software de Engenharia para Cálculos de Sistemas de Armazenagem");

        jLresultado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLresultado.setText("RESULTADO");
        jLresultado.setToolTipText("");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("INFORME O NÚMERO DE MONTANTES  NO CONJUNTO NA DIREÇÃO");
        jLabel13.setToolTipText("");

        nMontantesConjunto.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        nMontantesConjunto.setToolTipText("Informe o número de montantes");
        nMontantesConjunto.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        nMontantesConjunto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nMontantesConjuntoKeyTyped(evt);
            }
        });

        hEstrutura.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        hEstrutura.setToolTipText("Informe a altura em milímetros");
        hEstrutura.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        hEstrutura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hEstruturaKeyTyped(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("INFORME A ALTURA TOTAL DA ESTRUTURA ................................");
        jLabel14.setToolTipText("");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("DO CORREDOR");
        jLabel15.setToolTipText("");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("INFORME O NÚMERO DE PARES DE LONGARINAS POR MÓDULO");
        jLabel16.setToolTipText("");

        qParesLongarinas.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        qParesLongarinas.setToolTipText("Informe o número de pares de longarinas");
        qParesLongarinas.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        qParesLongarinas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                qParesLongarinasKeyTyped(evt);
            }
        });

        dVerticalForaPrumo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        dVerticalForaPrumo.setToolTipText("Informe a distância entre a vertical e posição fora de prumo");
        dVerticalForaPrumo.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        dVerticalForaPrumo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dVerticalForaPrumoKeyTyped(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("INFORME A DISTÂNCIA ENTRE A VERTICAL E POSIÇÃO FORA PRUMO");
        jLabel17.setToolTipText("");

        jBcalcular.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBcalcular.setText("CALCULAR");
        jBcalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBcalcularActionPerformed(evt);
            }
        });

        jBlimpar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBlimpar.setText("LIMPAR");
        jBlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBlimparActionPerformed(evt);
            }
        });

        respostaResultado.setEditable(false);
        respostaResultado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        respostaResultado.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        respostaResultado.setToolTipText("O resultado final é:");
        respostaResultado.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("IMPERFEIÇÕES MONTANTES NÃO CONTRAVENTADOS");
        jLabel3.setToolTipText("");

        jBimprimir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBimprimir.setText("IMPRIMIR");
        jBimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBimprimirActionPerformed(evt);
            }
        });

        jBsair.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBsair.setText("SAIR");
        jBsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBsairActionPerformed(evt);
            }
        });

        mensagemConclusao.setEditable(false);
        mensagemConclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mensagemConclusao.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mensagemConclusao.setToolTipText("A conclusão é:");
        mensagemConclusao.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        jBvoltarmenu1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jBvoltarmenu1.setText("VOLTAR AO MENU PRINCIPAL");
        jBvoltarmenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBvoltarmenu1ActionPerformed(evt);
            }
        });

        jLconclusao.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLconclusao.setText("CONCLUSÃO");
        jLconclusao.setToolTipText("");

        javax.swing.GroupLayout jPanelImagemApoioLayout = new javax.swing.GroupLayout(jPanelImagemApoio);
        jPanelImagemApoio.setLayout(jPanelImagemApoioLayout);
        jPanelImagemApoioLayout.setHorizontalGroup(
            jPanelImagemApoioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelImagemApoioLayout.createSequentialGroup()
                .addComponent(jLimagemapoio)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        jPanelImagemApoioLayout.setVerticalGroup(
            jPanelImagemApoioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelImagemApoioLayout.createSequentialGroup()
                .addComponent(jLimagemapoio)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemasdeArmazenagem/PP05.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel15)
                                .addComponent(jLabel13))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jBsair, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jBimprimir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jBvoltarmenu1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel3)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel17)
                                            .addComponent(jLabel14)
                                            .addComponent(jLabel16)))
                                    .addGap(7, 7, 7)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(qParesLongarinas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(hEstrutura, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(dVerticalForaPrumo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(nMontantesConjunto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(respostaResultado, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jBlimpar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jBcalcular, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE))
                            .addComponent(mensagemConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(222, 222, 222)
                                .addComponent(jLresultado))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(224, 224, 224)
                                .addComponent(jLconclusao)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(56, 56, 56)))
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanelImagemApoio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(2, 2, 2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanelImagemApoio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel3)
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(nMontantesConjunto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(qParesLongarinas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(hEstrutura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dVerticalForaPrumo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17))
                        .addGap(29, 29, 29)
                        .addComponent(jBcalcular)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBlimpar)
                        .addGap(29, 29, 29)
                        .addComponent(jLresultado, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(respostaResultado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(jLconclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mensagemConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(jBvoltarmenu1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBimprimir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBsair))
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    Float numeroMontantes, quantidadeParesLongarinas, alturaEstrutura, distanciaVerticalForaPrumo, deltaS, resultadoFinal;
    Integer deltaL, auxA, auxB, auxC, auxD, auxE;
    
    

    private void jBcalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBcalcularActionPerformed
        if (nMontantesConjunto.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar o número de montantes por conjunto", null, WIDTH);
        }
        if (qParesLongarinas.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a quantidade de pares de longarinas por módulo", null, WIDTH);
        }
        if (hEstrutura.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a altura da estrutura", null, WIDTH);
        }
        if (dVerticalForaPrumo.getText().equals("")) {
            JOptionPane.showMessageDialog(null,"Favor informar a distância entre a vertical e posição fora de prumo", null, WIDTH);
        }
        else {
            numeroMontantes = Float.valueOf(nMontantesConjunto.getText());
            quantidadeParesLongarinas = Float.valueOf(qParesLongarinas.getText());
            alturaEstrutura = Float.valueOf(hEstrutura.getText());
            distanciaVerticalForaPrumo = Float.valueOf(dVerticalForaPrumo.getText());
            deltaL = 0;
            deltaS = distanciaVerticalForaPrumo / alturaEstrutura;
            auxA = 1;
            auxB = 2;
            
            float auxAB;
            auxAB = (float) auxA / auxB;
            
            float auxAnM;
            auxAnM = auxA / numeroMontantes;
            
            auxC = 5;
            float auxAC;
            auxAC = (float) auxA / auxC;
            
            float auxAqPl;
            auxAqPl = auxA / quantidadeParesLongarinas;
            
            auxD = 2;
            float auxDdL = auxD * deltaS;
            
            float resA;
            resA = (auxAB + auxAnM);
            
            float resB;
            resB =  (auxAC + auxAqPl);
            
            float resC;
            resC = (auxDdL + deltaL);
            
            float resD;
            resD = resB * resC;
            
            float resE;
            resE = (float) Math.sqrt(resA);
            
            float resF;
            resF = (float) Math.sqrt(resD);
            
            resultadoFinal = resE * resF;
            
            float deltaCompareA;
            deltaCompareA = auxB * deltaS; 
            
            float deltaCompareB;
            deltaCompareB = deltaS;
            
            float deltaCompareC;
            auxE = 500;
            deltaCompareC = (float) auxA / auxE;
            
            respostaResultado.setText(String.valueOf(resultadoFinal));
            
            if (resultadoFinal < deltaCompareA) {
            mensagemConclusao.setText("Imperfeição fora das tolerâncias");
            } else {
            mensagemConclusao.setText("Imperfeição dentro das tolerâncias");
            }
            }
    }//GEN-LAST:event_jBcalcularActionPerformed
            
    private void jBlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBlimparActionPerformed
        nMontantesConjunto.setText("");
        qParesLongarinas.setText("");
        hEstrutura.setText("");
        dVerticalForaPrumo.setText("");
        respostaResultado.setText("");
        mensagemConclusao.setText("");
    }//GEN-LAST:event_jBlimparActionPerformed

    private void jBimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBimprimirActionPerformed
    String resultadoFinalPdf, nMontantesPdf, qParLongPdf, hEstutPdf, distVertFPrPdf; 
    resultadoFinalPdf = String.valueOf(respostaResultado.getText());
    nMontantesPdf = String.valueOf(nMontantesConjunto.getText());
    qParLongPdf = String.valueOf(qParesLongarinas.getText());
    hEstutPdf = String.valueOf(hEstrutura.getText());
    distVertFPrPdf = String.valueOf(dVerticalForaPrumo.getText());
    Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("C://temp//Imperfeicoes Montantes.pdf"));
    document.open();
        boolean add;
        add = document.add(new Paragraph("Software de Engenharia para Cálculos de Sistemas de Armazenagem"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("Resultados: Imperfeições Montantes Não Contraventados"));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("   Delta é igual a :" + resultadoFinalPdf));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("CONCLUSÃO: " + " Com " + (nMontantesPdf) + " montantes no conjunto na direção do corredor e com " + (qParLongPdf) + " pares de longarinas e a estrutura com " + (hEstutPdf) + " mm" + " e a distância vertical fora de prumo igual a " + (distVertFPrPdf) + " mm, o resultado de delta é igual a: " + (resultadoFinalPdf)));
        add = document.add(new Paragraph(" "));
        add = document.add(new Paragraph("                    Cezar A. Pires .............. V 1.00"));
            
        JOptionPane.showMessageDialog(null,"Arquivo salvo com sucesso C:\temp (Imperfeicoes Montantes)", null, WIDTH);
    }
    catch(DocumentException | IOException de)
    { System.err.println(de.getMessage());
    }
    document.close();         
    }//GEN-LAST:event_jBimprimirActionPerformed

    private void jBsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBsairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBsairActionPerformed

    private void jBvoltarmenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBvoltarmenu1ActionPerformed
        this.dispose();
        new SistemasPortaPaletes().setVisible(true);
    }//GEN-LAST:event_jBvoltarmenu1ActionPerformed

    private void nMontantesConjuntoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nMontantesConjuntoKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_nMontantesConjuntoKeyTyped

    private void qParesLongarinasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qParesLongarinasKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_qParesLongarinasKeyTyped

    private void hEstruturaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hEstruturaKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_hEstruturaKeyTyped

    private void dVerticalForaPrumoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dVerticalForaPrumoKeyTyped
    char vchar = evt.getKeyChar();
    if(!(Character.isDigit(vchar))
       || (vchar == KeyEvent.VK_BACK_SPACE))
       evt.consume();
    }//GEN-LAST:event_dVerticalForaPrumoKeyTyped
  
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(() -> {
            new ImperfeiçõesMontantesNãoContraventados().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField dVerticalForaPrumo;
    private javax.swing.JTextField hEstrutura;
    private javax.swing.JButton jBcalcular;
    private javax.swing.JButton jBimprimir;
    private javax.swing.JButton jBlimpar;
    private javax.swing.JButton jBsair;
    private javax.swing.JButton jBvoltarmenu1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLconclusao;
    private javax.swing.JLabel jLimagemapoio;
    private javax.swing.JLabel jLresultado;
    private javax.swing.JPanel jPanelImagemApoio;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JTextField mensagemConclusao;
    private javax.swing.JTextField nMontantesConjunto;
    private javax.swing.JTextField qParesLongarinas;
    private javax.swing.JTextField respostaResultado;
    private javax.swing.JTextField respostaResultado2;
    // End of variables declaration//GEN-END:variables
}
